package com.ejemploajaxservidor.model;

public class EjemploAjaxServidor {

}
